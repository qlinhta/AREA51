package com.example.joinfive.model;

public class PlayerData {
    private String name;
    private int score;

    public PlayerData(String name) {
        this.name = name;
    }

}
