package com.example.joinfive.model.grid;

public enum Direction {
    HORIZONTAL, VERTICAL, FALL, RISE
}
